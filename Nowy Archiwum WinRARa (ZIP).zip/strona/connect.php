<?php
$dbServer = 'localhost';
$dbUser = 'u235805072_bembol';
$dbPassword = 'B3mbol123!';
$dbName = 'u235805072_bieg';

$mysqli = new mysqli($dbServer, $dbUser, $dbPassword, $dbName);
