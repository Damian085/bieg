<?php

function mejl($mail,$imie,$nazwisko){
$to = $mail;
$subject = "Potwierdzenie zgłoszenia";
$message = "Witaj $imie $nazwisko. 
        To jest twoja rezerwacja 
        A to twój mail $mail";
$headers = 'From: admin@biegniemybypomagac.pl' . "\r\n" .
'Reply-To: admin@biegniemybypomagac.pl' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
    
    mail($to, $subject, $message, $headers); 

}

